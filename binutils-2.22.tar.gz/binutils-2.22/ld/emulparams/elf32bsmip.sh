. ${srcdir}/emulparams/elf32bmip.sh
ENTRY=__start
EXTRA_EM_FILE=irix
