. ${srcdir}/emulparams/shelf64_nbsd.sh

OUTPUT_FORMAT="elf64-sh64l-nbsd"
