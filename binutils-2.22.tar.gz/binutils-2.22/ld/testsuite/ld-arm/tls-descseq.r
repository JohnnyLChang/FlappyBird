
.*:     file format elf32-.*arm

DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
[0-9a-f]+ R_ARM_TLS_DESC    lib_gd2
