
const char *text = "Hello world!\n";

