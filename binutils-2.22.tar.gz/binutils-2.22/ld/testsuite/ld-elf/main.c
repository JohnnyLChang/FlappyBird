#include <stdio.h>

int
main (void)
{
  printf ("MAIN\n");
  return 0;
}
