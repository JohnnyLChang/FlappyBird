#include <stdio.h>

void
foo ()
{
  printf ("TEST1\n");
}
