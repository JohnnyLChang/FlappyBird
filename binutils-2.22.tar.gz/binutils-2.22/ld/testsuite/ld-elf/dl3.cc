#include "dl3header.h"

void
f (void)
{
  throw (A (42));
}
