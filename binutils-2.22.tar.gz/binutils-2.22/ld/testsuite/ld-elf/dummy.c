/* An empty file.  */
