c1
c2
c3
c4
d1
d2
d3
d4
